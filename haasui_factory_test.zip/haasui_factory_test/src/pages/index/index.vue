<template>
  <div class="wrapper">
    <canvas
      @touchstart="onTouchStart"
      @touchmove="onTouchMove"
      @touchend="onTouchEnd"
      :width="width" :height="height" ref="c1">
    </canvas>
  </div>
</template>

<script>
const deviceWidth = WXEnvironment.deviceWidth // 240

const deviceHeight = WXEnvironment.deviceHeight // 240

const CHECK_精度px = 40

class StepChecker {
  constructor(step) {
    this.step = step
    this.blocks = []
    this.init()
  }
  init() {
    let {topLeft, width, height, vertical} = this.step
    if (vertical) {
      for (let px=0; px < height; px += CHECK_精度px) {
        this.blocks.push({
          left: topLeft[0], right: topLeft[0]+width,
          top: topLeft[1]+px, bottom: topLeft[1]+px+height,
        })
      }
    } else {
      for (let px=0; px < width; px += CHECK_精度px) {
        this.blocks.push({
          left: topLeft[0]+px, right: topLeft[0]+px+width,
          top: topLeft[1], bottom: topLeft[1]+height,
        })
      }
    }
  }
  checkPoints(points) {
    const blocks = JSON.parse(JSON.stringify(this.blocks))
    let checkCnt = 0
    for (let block of blocks) {
      if (block.checked) continue
      for (let p of points) {
        let [x, y] = p
        // console.log(x, y)
        // console.log(JSON.stringify(block))
        if (x > block.left && x < block.right && y > block.top && y < block.bottom) {
          // checked
          block.checked = true
          checkCnt += 1
          break
        }
      }
    }
    console.log(`${checkCnt}/${blocks.length}`)
    return checkCnt === blocks.length
  }
}

export default {
  name: "index",
  data() {
    const widthMid = deviceWidth / 2
    const heightMid = deviceHeight / 2
    const hbarWidth = 100
    const vbarHeight = 100
    const steps = [
      {topLeft: [0, 0],                     width: hbarWidth, height: deviceHeight, vertical: true},
      {topLeft: [widthMid-hbarWidth/2, 0],  width: hbarWidth, height: deviceHeight, vertical: true},
      {topLeft: [deviceWidth-hbarWidth, 0], width: hbarWidth, height: deviceHeight, vertical: true},

      {topLeft: [0, 0],                     width: deviceWidth, height: vbarHeight, vertical: false},
      {topLeft: [0, deviceHeight-vbarHeight], width: deviceWidth, height: vbarHeight, vertical: false},
    ]
    this.steps = steps

    return {
      message: "",
      width: deviceWidth,
      height: deviceHeight,
    };
  },
  mounted() {
    this.ctx = typeof createCanvasContext === "function" ? createCanvasContext(this.$refs.c1) : this.$refs.c1.getContext("2d");
    let ctx = this.ctx
    this.stepIdx = 0
    this.onNextStep(0)
  },
  methods: {
    onTouchStart(evt) {
      let x = evt.changedTouches[0].pageX
      let y = evt.changedTouches[0].pageY
      this.lastX = x
      this.lastY = y
      this.touchPoints = []
      this.touchPoints.push([x, y])
    },
    onTouchMove(evt) {
      // JSCONSOLE: {"changedTouches":[{"pageX":235,"pageY":247,"screenX":235,"screenY":247}],"type":"touchmove"} __LOG
      // console.log(JSON.stringify(evt))
      let x = evt.changedTouches[0].pageX
      let y = evt.changedTouches[0].pageY
      let ctx = this.ctx
      ctx.beginPath()
      ctx.moveTo(this.lastX, this.lastY)
      ctx.lineTo(x, y)
      this.lastX = x
      this.lastY = y
      this.touchPoints.push([x, y])
      ctx.stroke()
    },
    onTouchEnd(evt) {
      const step = this.steps[this.stepIdx]
      const checker = new StepChecker(step)
      if (checker.checkPoints(this.touchPoints)) {
        console.log(`step ${this.stepIdx} 通过`)
        this.stepIdx += 1
        this.onNextStep(this.stepIdx)
      } else {
        console.log(`step ${this.stepIdx} 未通过`)
      }
      this.cleanScreen()
    },
    cleanScreen() {
      const ctx = this.ctx
      ctx.clearRect(0, 0, deviceWidth, deviceHeight)
      if (this.stepIdx < this.steps.length) {
        this.drawStepBg(this.steps[this.stepIdx])
      } else {
        ctx.font = '56px'
        ctx.fillText("成功", deviceWidth / 2, deviceHeight / 2)
      }
      ctx.font = '18px'
      ctx.fillText(`cur w: ${deviceWidth}, h: ${deviceHeight}`, 10, 40)
      ctx.fillText(`env w: ${WXEnvironment.deviceWidth}, h: ${WXEnvironment.deviceHeight}`, 10, 58)
    },
    onNextStep(stepIdx) {
      if (stepIdx >= this.steps.length) {
        console.log(`成功完成所有steps`)
        return
      }
      const step = this.steps[stepIdx]
      this.cleanScreen()
    },
    drawStepBg(step) {
      const ctx = this.ctx
      let width = step.width
      let height = step.height
      ctx.fillStyle = '#FF6A00'
      ctx.fillRect(...step.topLeft, width, height)
    }
  },
};
</script>

<style lang="less" scoped>
@import "../../styles/base.less";

.wrapper {
  justify-content: center;
  align-items: center;
  width: 100%;
  height: 100%;
}

</style>
