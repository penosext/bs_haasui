export class BasePage extends $falcon.Page {
  constructor() {
    super()
  }
}