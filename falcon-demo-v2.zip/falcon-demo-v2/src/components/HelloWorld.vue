<template>
  <text class="message">Now, let's use Vue.js to build your iot app</text>
</template>
<script>

export default {
  name: "HelloComponent",
  components: {},
  data() {
    return {
      msg:''
    };
  },
  methods: {
  },
};
</script>