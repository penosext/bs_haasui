/*
 * 基于quickjs的接口扩展mock
 */

export default {
  mockMethod(params) {
    console.log('mockMethod:', params);
  }
};