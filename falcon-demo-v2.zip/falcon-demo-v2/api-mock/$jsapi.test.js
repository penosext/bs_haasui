/*
 * jsapi扩展mock
 */
export default {
  testApi(params) {
    console.log('mock testApi', JSON.stringify(params));
  }
}