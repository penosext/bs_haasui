import Vue from 'vue';
import weex from 'falcon-vue-render';

weex.init(Vue);

const App = require('../src/pages/music/index.vue');
if(!window.$falcon){
  console.error('boot fail! please open _preview.app.html to preview app!');
} else {
  $falcon._web_boot_page(App, Vue, window);
}