
import AppJson from '../src/app.json';
import App from '../src/app.js';
$falcon._web_boot_app(App, AppJson);
  