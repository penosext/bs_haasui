import util from 'util';
import events from 'events';

let AC = function () {
	this.acOn = true;
	this.temp = 24;
	// 0:高 1:中 2:低
	this.wind = 1;
	// 0:除湿 1:制冷 2:制热 3:通风
	this.mode = 1;
};

util.inherits(AC, events.EventEmitter);

AC.prototype.setACOn = function (acOn) {
	if (this.acOn != acOn) {
		this.acOn = acOn;
		this.emit('acOn', acOn);
	}
};

AC.prototype.setTemp = function (temp) {
	if (this.temp != temp) {
		this.temp = temp;
		this.emit('temp', temp);
	}
};

AC.prototype.setWind = function (wind) {
	if (this.wind != wind) {
		this.wind = wind;
		this.emit('wind', wind);
	}
};
AC.prototype.formatWind = function (wind) {
	if (wind == 0) {
		return '高';
	} else if (wind == 1) {
		return '中';
	} else if (wind == 2) {
		return '低';
	}
	return '中';
};

AC.prototype.setMode = function (mode) {
	if (this.mode != mode) {
		this.mode = mode;
		this.emit('mode', mode);
	}
};
AC.prototype.formatMode = function (mode) {
	if (mode == 0) {
		return '除湿';
	} else if (mode == 1) {
		return '制冷';
	} else if (mode == 2) {
		return '制热';
	} else if (mode == 3) {
		return '通风';
	}
	return '制冷';
};

export default new AC;