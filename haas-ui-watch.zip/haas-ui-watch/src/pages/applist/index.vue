<template>
  <div class="page">
    <IndexList />
  </div>
</template>

<script>

import IndexList from "./components/index-list.vue";

export default {
  name: "index",
  components: { IndexList },
  data() {
    return {
    };
  },
  methods: {
  },
};
</script>

<style lang="less" scoped>
@import "../../style/base";

.page {
  align-items: center;
  background-color: black;
}
</style>