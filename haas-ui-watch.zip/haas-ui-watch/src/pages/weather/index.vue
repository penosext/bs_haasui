<template>
  <div class="page">
    <action-bar title="杭州市,晴" />
    <scroller showScrollbar="false">
      <div class="scroller">
        <div class="temperature-wrap">
          <div class="temperature">
            <text class="number">24</text>
            <text class="temperatureRange">19/26</text>
          </div>    
          <div class="centigrade-wrap">
            <text class="centigrade">℃</text>
          </div>
        </div>
        <div class="list">
          <div class="item1">
            <text class="item-text-left">周一</text>
            <image class="item-icon" resize="contain" :src="require('./images/sunny.png')" />
            <text class="item-text-right">19/26</text>
          </div>
          <div class="item">
            <text class="item-text-left">周二</text>
            <image class="item-icon" resize="contain" :src="require('./images/overcast.png')" />
            <text class="item-text-right">16/24</text>
          </div>
          <div class="item">
            <text class="item-text-left">周三</text>
            <image class="item-icon" resize="contain" :src="require('./images/cloudy.png')" />
            <text class="item-text-right">15/22</text>
          </div>
          <div class="item">
            <text class="item-text-left">周四</text>
            <image class="item-icon" resize="contain" :src="require('./images/overcast.png')" />
            <text class="item-text-right">15/24</text>
          </div>
          <div class="item">
            <text class="item-text-left">周五</text>
            <image class="item-icon" resize="contain" :src="require('./images/cloudy.png')" />
            <text class="item-text-right">16/27</text>
          </div>
          <div class="item">
            <text class="item-text-left">周六</text>
            <image class="item-icon" resize="contain" :src="require('./images/sunny.png')" />
            <text class="item-text-right">15/25</text>
          </div>
          <div class="item">
            <text class="item-text-left">周日</text>
            <image class="item-icon" resize="contain" :src="require('./images/sunny.png')" />
            <text class="item-text-right">16/24</text>
          </div>
        </div>
      </div>
  </scroller>
  </div>
</template>

<script>

import ActionBar from "../../components/action-bar.vue";

const component = {
  name: "weather",
  components: { ActionBar },
  data() {
    return {
      items: [
        {
          icon: require('./images/cloudy.png'),
          leftText: '周一',
          rightText: '19/26'
        },
        {
          icon: require('./images/cloudy.png'),
          leftText: '周二',
          rightText: '19/26'
        },
        {
          icon: require('./images/cloudy.png'),
          leftText: '周三',
          rightText: '19/26'
        },
        {
          icon: require('./images/cloudy.png'),
          leftText: '周四',
          rightText: '19/26'
        },  {
          icon: require('./images/cloudy.png'),
          leftText: '周五',
          rightText: '19/26'
        },
        {
          icon: require('./images/cloudy.png'),
          leftText: '周六',
          rightText: '19/26'
        },
        {
          icon: require('./images/cloudy.png'),
          leftText: '周日',
          rightText: '19/26'
        }
      ]
    };
  },
  computed: {
  },
  methods: {
  },
};

export default component;
</script>

<style scoped>
.page {
  align-items: center;
  background-image: linear-gradient(to bottom, #0045FF, #00C1FF);
}
.scroller {
  width: 240px;
  height: 565px;
  margin-top: 22px;
}
.temperature-wrap {
  flex-direction: row;
  height: 129px;
}
.temperature {
    flex-direction: column;
    /* align-self: center; */
    position:absolute;
    left: 62px;
    top: 2px;
}
.number {
    height: 86px;
    width: 116px;
    font-size: 110px;
    color: #FFFFFF;
    line-height: 84px;
    font-family: AlibabaSans102-Md;
    align-items:center;
    justify-content:center;
    align-self: center;
    text-align:center;
}
.centigrade-wrap {
    position: absolute;
    height: 33px;
    width: 26px;
    left: 175px;
}
.centigrade {
    font-size: 24px;
    color: #FFFFFF;
    align-items:center;
    justify-content:center;
    align-self:center;
}
.temperatureRange {
    margin-top: 10px;
    height: 33px;
    width: 69px;
    font-size: 24px;
    color: #FFFFFF;
    align-items:center;
    justify-content:center;
    align-self:center;
}
.list {
    border-radius: 16px;
    background-color: rgba(255, 255, 255, 0.23);
    margin-top: 33px;
    height: 334px;
    width: 232px;
    align-self: center;
}
.item1 {
    margin-top: 16px;
    color: #FFFFFF;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    line-height: 24px;
}
.item {
    margin-top: 20px;
    color: #FFFFFF;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    line-height: 24px;
}
.item-icon {
    width: 26.2px;
    height: 26.2px;
}
.item-text-left {
    padding-left: 17px;
    height: 24px;
    /* width: 40px; */
    font-size: 20px;
    color: #FFFFFF;
}
.item-text-right {
    padding-right: 17px;
    height: 24px;
    /* width: 55px; */
    font-size: 20px;
    color: #FFFFFF;
    text-align: right;
}
</style>
