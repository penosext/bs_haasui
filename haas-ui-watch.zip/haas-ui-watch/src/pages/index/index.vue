<template>
  <div class="page" @click="click">
    <Clock />
  </div>
</template>

<script>

import Clock from "../../components/clock/index.vue";

export default {
  name: "index",
  components: { Clock },
  data() {
    return {
    };
  },
  methods: {
    click(e) {
      $falcon.navTo('applist');
    }
  },
};
</script>

<style lang="less" scoped>
@import "../../style/base";

.page {
  justify-content: center;
  align-items: center;
  background-color: black;
}
</style>