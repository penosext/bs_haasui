<template>
  <div class="grid">
  </div>
</template>

<script>
export default {
  name: "index",
  data() {
    return {
    };
  },
  methods: {
  },
};
</script>

<style scoped>

.grid {
  justify-content: center;
  align-items: center;
}
</style>