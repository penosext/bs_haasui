import util from 'util';
import events from 'events';

let Light = function () {
	this.brightness = 0.5;
};

util.inherits(Light, events.EventEmitter);

Light.prototype.setBrightness = function (brightness) {
	if (this.brightness != brightness) {
		this.brightness = brightness;
		this.emit('brightness', brightness);
	}
	console.log('Light.brightness', brightness);
};
Light.prototype.formatBrightness = function () {
	return "" + parseInt((this.brightness)*100) + "%";
};

export default new Light;