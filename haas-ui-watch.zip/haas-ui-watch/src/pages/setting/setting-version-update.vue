<template>
  <div class="page">
    <action-bar title="版本更新" />
    <div class="content">
      <text class="version">1.0</text>
      <text class="tip">已经是最新版本</text>
    </div>
  </div>
</template>

<script>
import ActionBar from "../../components/action-bar.vue";
const component = {
  name: "VersionUpdate",
  components: { ActionBar },
  data() {
    return {
    };
  },
  mounted() {
  },
  beforeDestroy() {
  },
  methods: {
  },
};

export default component;
</script>

<style scoped>
.page {
  align-items: center;
  background-color: black;
}
.content {
  flex-direction: column;
}
.version {
  font-size: 72px;
  color: #FFFFFF;
  margin-top: 40px;
  align-self: center;
}
.tip {
  font-size: 20px;
  color: #FFFFFF;
  margin-top: 4px;
  align-self: center;
}
</style>
