<template>
  <div class="page index-wrapper">
    <slider infinite="true" class="slider-root" v-bind:index="sliderIndex" v-on:change="sliderChanged">
     <Clock></Clock>
     <ClockData></ClockData>
    </slider>
  </div>
</template>

<script src="./index.js"></script>
<style scoped src="./index.css"></style>
