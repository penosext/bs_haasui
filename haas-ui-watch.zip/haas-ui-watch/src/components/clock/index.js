import ClockData from './clock-data.vue'
import Clock from './clock.vue'

export default {
  name: 'App',
  components: { ClockData, Clock },
  data() {
    return {
      sliderIndex: 0,
    }
  },

  methods: {
    imgSrc(src) {
      return typeof (src) === 'string' ? src : src.default;
    },
    back() {
      // this.sliderIndex = 0;
    },
    sliderChanged(evt) {
      this.sliderIndex = evt.index;
      console.log('sliderChanged:', this.sliderIndex);
    }
  },
  beforeCreate() {
    console.log('beforeCreate');
  },
  created() {
    console.log('created');
  },
  beforeMount() {
    console.log('beforeMount');
  },
  mounted() {
    console.log('mounted');
  }
}