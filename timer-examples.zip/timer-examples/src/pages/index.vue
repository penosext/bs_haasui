<template>
  <div class="center">
    <div class="time-wrapper">
      <text class="text">{{ hours }}</text>
      <text class="text colon">{{ showColon ? ":" : " " }}</text>
      <text class="text">{{ minutes }}</text>
    </div>
  </div>
</template>

<script>
export default{
  data() {
    return {
      hours: 0,
      minutes: 0,
      showColon: true,
    };
  },
  methods: {
    onShow() {
      if (!this.timerId) {
        this.updateTime()
        this.timerId = setInterval(() => {
          this.updateTime()
        }, 1000)
      }
    },
    onHide() {
      if (this.timerId) {
        clearInterval(this.timerId)
        this.timerId = 0
      }
    },
    updateTime() {
      let now = new Date()
      this.hours = String(now.getHours()).padStart(2, "0")
      this.minutes = String(now.getMinutes()).padStart(2, "0")
      let seconds = String(now.getSeconds()).padStart(2, "0")
      this.showColon = !this.showColon
      console.log(`updateTime ${this.hours}:${this.minutes}:${seconds}`)
    },
  },
}
</script>
<style lang="less" scoped>
.center {
  align-items: center;
  justify-content: center;
}
.time-wrapper {
  flex-direction: row;
}
.colon {
  width: 10px;
}
.text {
  color: #606266;
}
</style>
