export class BasePage extends $falcon.Page {
  constructor() {
    super()
  }
  onShow() {
    super.onShow()
    if (this.$root.onShow) {
      console.log(`page ${this.$root.name} onShow`)
      this.$root.onShow()
    }
  }
  onHide() {
    super.onHide()
    if (this.$root.onHide) {
      console.log(`page ${this.$root.name} onHide`)
      this.$root.onHide()
    }
  }
}