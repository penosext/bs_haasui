<!-- 指针表盘 -->
<template>
<div class="page">
  <!-- 表盘绘制区域，相对外层页面居中显示 -->
  <div class="clock-wrapper">
    <!-- 天气绘制区域，左侧显示 -->
    <div class="weather-wrap">
      <image class="weather-icon" :src="require('../images/cloudy.png')" />
      <text class="weather-text">18℃</text>
    </div>

    <!-- 日期绘制区域，月日 & 星期几，居右显示 -->
    <div class="date-wrapper">
      <text class="date-text">{{ dateText }}</text>
    </div>

    <!-- 圆环表盘，刻度 -->
    <div class="clock-scale clock-scale0" />
    <div class="clock-scale clock-scale1" />
    <div class="clock-scale clock-scale2" />
    <div class="clock-scale clock-scale3" />
    <div class="clock-scale clock-scale4" />
    <div class="clock-scale clock-scale5" />
    <div class="clock-scale clock-scale6" />
    <div class="clock-scale clock-scale7" />
    <div class="clock-scale clock-scale8" />
    <div class="clock-scale clock-scale9" />
    <div class="clock-scale clock-scale10" />
    <div class="clock-scale clock-scale11" />

    <!-- 时分秒，指针 -->
    <div class="pointer-hour" :style="hStyle" />
    <div class="pointer-minute" :style="mStyle" />
    <div class="pointer-second" :style="sStyle" />

    <!-- 指针上的圆环 -->
    <div class="pointer-cover">
      <div class="pointer-cover-inner" />
    </div>
  </div>
</div>
</template>
<script>
const WEEKDAYS = ["日", "一", "二", "三", "四", "五", "六"]
export default {
  data() {
    // 时分秒的初始角度计算
    const degs = this.caculateDeg()
    return {
      ...degs
    }
  },
  computed: {
    dateText() {
      const now = new Date()
      const month = String(now.getMonth() + 1).padStart(2, "0")
      const date = String(now.getDate()).padStart(2, "0")
      const day = WEEKDAYS[new Date().getDay()]

      return `${month}.${date} 周${day}`
    },
    hStyle() {
      return {
        transform: `rotate(${this.hours}deg)`
      }
    },
    mStyle() {
      return {
        transform: `rotate(${this.minutes}deg)`
      }
    },
    sStyle() {
      return {
        transform: `rotate(${this.seconds}deg)`
      }
    }
  },
  methods: {
    onShow() {
      if (!this.timerId) {
        this.updateTime()
      }
    },
    onHide() {
      if (this.timerId) {
        clearTimeout(this.timerId)
        this.timerId = 0
      }
    },
    // 定期更新时间 & 指针角度
    updateTime() {
      this.timerId && clearTimeout(this.timerId)
      const result = this.caculateDeg()
      this.hours = result.hours
      this.minutes = result.minutes
      this.seconds = result.seconds
      this.timerId = setTimeout(() => {
        this.updateTime()
      }, 1000 - (Date.now() % 1000))
    },
    // 计算时分秒指针角度
    caculateDeg() {
      const now = new Date()
      const hours = now.getHours() % 12
      const minutes = now.getMinutes()
      const seconds = now.getSeconds()

      const sDeg = seconds * 6
      const mDeg = (minutes * 60 + seconds) * 0.1  //每一秒走0.1度
      const hDeg = ((hours % 12) * 60 + minutes) * 0.5  //每分钟走0.25度
      return {
        hours: parseInt(hDeg),
        minutes: parseInt(mDeg),
        seconds: parseInt(sDeg)
      }
    }
  }
}
</script>
<style lang="less" scoped>
@import "base.less";
@import "./clock-scale.less";

.page {
  align-items: center;
  justify-content: center;
  background-color: @background-color;
}

// 表盘绘制区域
.clock-wrapper {
  background-color: #000000;
  width: 600px;
  height: 380px;
  border-radius: 24px;
  align-self: center;
  position: relative;
  left:0;
  top:0;
}

// 左侧天气绘制区域
.weather-wrap {
  position:absolute;
  flex-direction: row;
  left:96px;
  top:166px;
}
.weather-icon {
  width: 51px;
  height: 51px;
  margin-right:6px;
}
.weather-text {
  color: @white;
  font-size:30px;
  line-height: 51px;;
}

// 右侧日期绘制区域，月日 & 星期几
.date-wrapper{
  position:absolute;
  right:83px;
  top:166px;
}
.date-text{
  color: @white;
  font-size:30px;
}

// 指针上的圆环
.pointer-cover {
  width: 16px;
  height: 16px;
  position: absolute;
  left: 292px;
  top: 182px;
  border-radius: 8px;
  background-color: #000000;
  align-items: center;
  justify-content: center;
}
.pointer-cover-inner {
  width: 12px;
  height: 12px;
  background-color: #ff0000;
  border-radius: 6px;
}

// 时分秒指针静态样式，其中旋转通过动态 style 控制
.pointer-hour,
.pointer-minute,
.pointer-second {
  position: absolute;
  background-color: @white;
  box-shadow: 0px 0px 6px #000;
}
.pointer-hour {
  width: 30px;
  height: 120px;
  left: 285px;
  top: 85px;
  border-radius: 15px;
  transform-origin: 50% 105px;
}
.pointer-minute {
  width: 20px;
  height: 180px;
  left: 290px;
  top: 20px;
  border-radius: 10px;
  transform-origin: 50% 170px;
}
.pointer-second {
  width: 4px;
  height: 195px;
  left: 298px;
  top: 6px;
  background-color: #ff0000;
  border-radius: 3px;
  transform-origin: 50% 184px;
}

</style>
