<template>
<div class="page">
  <div class="scene-wrapper">
    <!-- 右上角开关按钮 -->
    <div class="switch-button-wrap" @click="toggleSwitch">
      <image style="width: 44px;height: 44px;" resize="contain" :src="require('../images/off.png')"/>
    </div>
    <!-- 风速调节器 -->
    <div class="speed-slider-wrapper">
      <slider
        class="speed-slider"
        infinite="true"
        :index="speedIndex"
        @change="speedIndex = $event.index"
        previousMargin="100px"
        nextMargin="100px"
        :enableAcceleration="true"
      >
        <text
          v-for="(item, index) in ['Low', 'Mid', 'High']"
          :key="index"
          @click="speedIndex = index"
          class="speed-item"
          :class="{'speed-item-selected': index === speedIndex}"
        >{{ item }}</text>
      </slider>
      <text class="label-fan">Fan</text>
    </div>
    <!-- 温度调节器 -->
    <div class="temperature-wrap">
      <div class="temperature-ctrl-wrap" @click="tempMinus">
        <image class="ctrl-minus" resize="contain" :src="require('../images/minus.png')" />
      </div>
      <div class="label-temperature-wrapper">
        <text class="label-temperature">{{ temperatureCurrent }}</text>
        <text class="label-temperature-unit">℃</text>
      </div>
      <div class="temperature-ctrl-wrap" @click="tempPlus">
        <image class="ctrl-plus" resize="contain" :src="require('../images/plus.png')" />
      </div>
    </div>
    <!-- 模式选择器 -->
    <slider
      class="mode-slider"
      infinite="true"
      :index="modeIndex"
      @change="modeIndex = $event.index"
      previousMargin="80px"
      nextMargin="80px"
      :enableAcceleration="true"
    >
      <img
        v-for="(item, index) in modes"
        @click="modeIndex = index"
        :key="'mode' + index"
        :src="modes[index]"
        :class="'mode-slider-image' + (index === modeIndex ? ' mode-item-selected' : '')"
        resize="contain"
      />
    </slider>
    
    <div class="air-cover-wrapper" v-if="airClose">
      <text class="air-pop-title">Air Conditioning</text>
      <image class="switch-button-big" resize="contain" :src="require('../images/off.png')" @click="toggleSwitch" />
    </div>
  </div>
</div>
</template>

<script>
export default {
  data() {
    return {
      speedIndex: 0,
      modeIndex: 0,
      temperatureCurrent: 25,
      modes: [require("../images/sun.png"), require("../images/snow.png"), require("../images/water.png")],
      airClose: false
    };
  },
  methods: {
    toggleSwitch() {
      // 开关浮层显示
      this.airClose = !this.airClose
    },
    tempMinus() {
      // 减少温度，不小于 16
      if (this.temperatureCurrent > 16) {
        this.temperatureCurrent--
      }
      console.log(`tempMinus ${this.temperatureCurrent}`)
    },
    tempPlus() {
      // 增加温度，不大于 32
      if (this.temperatureCurrent < 32) {
        this.temperatureCurrent++
      }
      console.log(`tempPlus ${this.temperatureCurrent}`)
    }
  }
};
</script>

<style lang="less" scoped>
@import "base.less";

.page {
  align-items: center;
  justify-content: center;
  background-color: @background-color;
}

.scene-wrapper {
  flex-direction: column;
  justify-content: flex-start;
  align-items: stretch;
  background-color: @card-background-color;
  width: 720px;
  height: 380px;
  align-self: center;
  border-radius: 24px;
  position: relative;
  padding-top:26px;
}

// 右上角按钮
.switch-button-wrap{
  width:78px;
  height:78px;
  border-radius:50px;
  position: absolute;
  right: 18px;
  top: 18px;
  align-items: center;
  justify-content: center;
}
// 右上角按钮按下效果，背景透明度0.2
.switch-button-wrap:active{
  background-color: rgba(255,255,255, 0.2);
}

// 风速调节器
.speed-slider-wrapper {
  position: relative;
  width: 300px;
  align-items: center;
  align-self: center;
}
.speed-slider {
  width: 100%;
  height: 60px;
}
.speed-item {
  color: @text-color;
  opacity: 0.2;
  font-size: 28px;
  width: 100px;
  line-height: 60px;
  text-align: center;
  font-weight: bold;
}
.speed-item-selected {
  opacity: 1;
  font-size: 32px;
}
.label-fan {
  color: @text-color;
  opacity: 0.6;
}

// 温度调节整体 layout，横向布局
.temperature-wrap {
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
  padding: 0 60px;
  margin-top: 10px;
}
// 温度调节按钮样式
.temperature-ctrl-wrap {
  width: 100px;
  height: 100px;
  align-items: center;
  justify-content: center;
  border-radius:50px;
}
// 温度调节按钮按下效果，背景透明 0.2
.temperature-ctrl-wrap:active{
  background-color: rgba(255,255,255, 0.2);
}
.ctrl-minus {
  width: 38px;
  height: 10px;
}
.ctrl-plus {
  width: 46px;
  height: 46px;
}
// 温度数字，横向布局，左边数字，右边摄氏度符号
.label-temperature-wrapper {
  flex-direction: row;
  margin-left:35px;
}
// 数字
.label-temperature {
  font-size: 120px;
  color: @text-color;
}
// 摄氏度符号
.label-temperature-unit {
  font-size: 30px;
  color: @text-color;
  padding-top: 30px;
}

// 模式调节，滑动选择器
.mode-slider {
  width: 260px;
  height: 50px;
  margin-top: 16px;
  align-self: center;
}
.mode-slider-image {
  width: 44px;
  height: 44px;
  opacity: 0.2;
}
.mode-item-selected {
  opacity: 1;
}

// 开关浮层样式，绝对布局
.air-cover-wrapper {
  width: 100%;
  height: 380px;
  padding-top: 35px;
  align-items: center;
  justify-content: flex-start;
  background-color: rgba(0, 0, 0, 0.95);
  position:absolute;
  border-radius: 24px;
  left:0;
  top:0;
}
.air-pop-title {
  color: @white;
  font-size: 36px;
  text-align: center;
}
.switch-button-big {
  color: @white;
  margin-top: 70px;
  font-weight: bold;
  width:129px;
  height:132px;
}
</style>
